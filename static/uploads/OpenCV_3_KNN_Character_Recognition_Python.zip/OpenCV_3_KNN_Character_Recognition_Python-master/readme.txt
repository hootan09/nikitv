The video pretty much explains it all:
https://www.youtube.com/watch?v=c96w1JS28AY
